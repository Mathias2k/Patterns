﻿namespace ConsoleApp1.Creator
{
    public abstract class LancheFactoryMethod
    {
        public abstract Lanche CriarLanche(int tipo);
    }
}
